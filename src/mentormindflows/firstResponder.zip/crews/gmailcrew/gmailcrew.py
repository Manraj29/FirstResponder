from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
# import gmail_tool
from mentormindflows.crews.gmailcrew.tools.gmail_tool import GmailTool
@CrewBase
class Gmailcrew():
    """Gmailcrew crew"""
    agents_config = 'config/agents.yaml'
    tasks_config = 'config/tasks.yaml'

    @agent
    def gmail_draft_agent(self) -> Agent:
        return Agent(
            config=self.agents_config['gmail_draft_agent'],
            verbose=True,
            tools=[GmailTool()],
        )

    @task
    def gmail_draft_task(self) -> Task:
        return Task(
            config=self.tasks_config['gmail_draft_task'],
        )

    @crew
    def crew(self) -> Crew:
        """Creates the Gmailcrew crew"""

        return Crew(
            agents=self.agents, # Automatically created by the @agent decorator
            tasks=self.tasks, # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
        )
